const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const { Gateway, Wallets } = require('fabric-network');
const path = require('path');
const fs = require('fs');

// Initialize app
const app = express();
app.use(cors());
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/blockchainVoting', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => console.log('Connected to MongoDB'));

// Define schemas and models
const voterSchema = new mongoose.Schema({
  voterId: String, // Voter ID
  pin: String, // MFA PIN
  mobile: String, // Mobile number for OTP
});
const Voter = mongoose.model('Voter', voterSchema);

const otpSchema = new mongoose.Schema({
  mobile: { type: String, required: true }, // Mobile number
  otp: { type: String, required: true }, // OTP
  expiresAt: { type: Date, required: true }, // Expiration time
});
const OTP = mongoose.model('OTP', otpSchema);

// JWT secret key
const JWT_SECRET = 'your_jwt_secret_key';

// Hyperledger Fabric setup
let contract;

async function initFabric() {
  const ccpPath = path.resolve(__dirname, '..', 'fabric-samples', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
  const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

  const walletPath = path.join(process.cwd(), 'wallet');
  const wallet = await Wallets.newFileSystemWallet(walletPath);

  const gateway = new Gateway();
  await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });

  const network = await gateway.getNetwork('mychannel');
  contract = network.getContract('voting');
}

initFabric();

// API routes

// Login route
app.post('/login', async (req, res) => {
  try {
    const { voterId, pin } = req.body;

    // Check if voter exists
    const voter = await Voter.findOne({ voterId, pin });
    if (!voter) {
      return res.status(401).json({ success: false, message: 'Invalid Voter ID or PIN' });
    }

    // Generate JWT token
    const token = jwt.sign({ voterId: voter.voterId }, JWT_SECRET, { expiresIn: '1h' });
    res.json({ success: true, token });
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Send OTP route
app.post('/send-otp', async (req, res) => {
  try {
    const { mobile } = req.body;

    // Check if the mobile number is provided
    if (!mobile) {
      return res.status(400).json({ success: false, message: 'Mobile number is required' });
    }

    // Use a fixed OTP for testing
    const otp = '260800';

    // Set OTP expiration time (e.g., 5 minutes from now)
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

    // Save the OTP in the database
    await OTP.create({ mobile, otp, expiresAt });

    // Simulate sending OTP (in a real-world scenario, integrate with an SMS API)
    console.log(`Sending OTP ${otp} to mobile ${mobile}`);

    res.json({ success: true, message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Error sending OTP:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Verify OTP route
app.post('/verify-otp', async (req, res) => {
  try {
    const { mobile, otp } = req.body;

    // Check if mobile and OTP are provided
    if (!mobile || !otp) {
      console.log('Missing mobile or OTP');
      return res.status(400).json({ success: false, message: 'Mobile number and OTP are required' });
    }

    console.log(`Verifying OTP for mobile: ${mobile}, OTP: ${otp}`);

    // Find the OTP in the database
    const otpRecord = await OTP.findOne({ mobile, otp });
    console.log('OTP Record:', otpRecord);

    // Check if the OTP exists and is not expired
    if (!otpRecord || otpRecord.expiresAt < new Date()) {
      console.log('Invalid or expired OTP');
      return res.status(401).json({ success: false, message: 'Invalid or expired OTP' });
    }

    // OTP is valid, delete it from the database (optional)
    await OTP.deleteOne({ _id: otpRecord._id });

    res.json({ success: true, message: 'OTP verified successfully' });
  } catch (error) {
    console.error('Error verifying OTP:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Submit vote route
app.post('/vote', async (req, res) => {
  const { voterId, candidateId } = req.body;

  try {
    // Submit the vote to the blockchain
    const response = await contract.submitTransaction('vote', voterId, candidateId);
    res.json({ success: true, message: response.toString() });
  } catch (error) {
    console.error('Error submitting vote:', error);
    res.status(500).json({ success: false, message: 'Failed to submit vote' });
  }
});

// Get results route
app.get('/results', async (req, res) => {
  try {
    const response = await contract.evaluateTransaction('getResults');
    res.json(JSON.parse(response.toString()));
  } catch (error) {
    console.error('Error fetching results:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch results' });
  }
});

// Start the server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));