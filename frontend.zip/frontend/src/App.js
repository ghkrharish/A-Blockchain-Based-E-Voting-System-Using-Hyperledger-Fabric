import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import axios from 'axios';
import './styles/App.css';

function Login({ onLogin }) {
  const [voterId, setVoterId] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:5000/login', { voterId, pin });
      if (response.data.success) {
        onLogin(response.data.token); // Pass the token to the parent
      } else {
        setError('Invalid Voter ID or PIN. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <input
        type="text"
        placeholder="Enter your Voter ID"
        value={voterId}
        onChange={(e) => setVoterId(e.target.value)}
      />
      <input
        type="password"
        placeholder="Enter your PIN"
        value={pin}
        onChange={(e) => setPin(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
}

function MFA({ onVerified }) {
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');

  const sendOtp = async () => {
    try {
      const response = await axios.post('http://localhost:5000/send-otp', { mobile });
      if (response.data.success) {
        alert('OTP sent to your mobile number.');
      } else {
        setError('Failed to send OTP. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    }
  };

  const verifyOtp = async () => {
    try {
      const response = await axios.post('http://localhost:5000/verify-otp', { mobile, otp });
      if (response.data.success) {
        onVerified(); // Verification successful
      } else {
        setError('Invalid OTP. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    }
  };

  return (
    <div>
      <h2>Multi-Factor Authentication</h2>
      <input
        type="text"
        placeholder="Enter your mobile number"
        value={mobile}
        onChange={(e) => setMobile(e.target.value)}
      />
      <button onClick={sendOtp}>Send OTP</button>
      <br />
      <input
        type="text"
        placeholder="Enter OTP"
        value={otp}
        onChange={(e) => setOtp(e.target.value)}
      />
      <button onClick={verifyOtp}>Verify OTP</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
}

function VoteForm() {
  const [candidate, setCandidate] = useState('');
  const [candidates, setCandidates] = useState([]);

  useEffect(() => {
    const fetchCandidates = async () => {
      const response = await axios.get('http://localhost:5000/candidates');
      setCandidates(response.data);
    };
    fetchCandidates();
  }, []);

  const submitVote = async () => {
    try {
      await axios.post('http://localhost:5000/vote', { candidate });
      alert('Vote submitted!');
    } catch (error) {
      alert('Error submitting vote');
    }
  };

  return (
    <div>
      <h2>Vote for a Candidate</h2>
      <select value={candidate} onChange={(e) => setCandidate(e.target.value)}>
        <option value="">Select a candidate</option>
        {candidates.map((c) => (
          <option key={c._id} value={c.name}>
            {c.name}
          </option>
        ))}
      </select>
      <button onClick={submitVote}>Submit Vote</button>
      <br />
      <Link to="/results">View Results</Link>
    </div>
  );
}

function Results() {
  const [results, setResults] = useState([]);

  useEffect(() => {
    const fetchResults = async () => {
      const response = await axios.get('http://localhost:5000/results');
      setResults(response.data);
    };
    fetchResults();
  }, []);

  return (
    <div>
      <h2>Voting Results</h2>
      <ul>
        {results.map((result) => (
          <li key={result._id}>
            {result._id}: {result.count} votes
          </li>
        ))}
      </ul>
      <Link to="/">Back to Voting</Link>
    </div>
  );
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isVerified, setIsVerified] = useState(false);

  const handleLogin = (token) => {
    localStorage.setItem('token', token);
    setIsAuthenticated(true);
  };

  return (
    <Router>
      <div className="App">
        <h1>Blockchain Voting System</h1>
        {!isAuthenticated ? (
          <Login onLogin={handleLogin} />
        ) : !isVerified ? (
          <MFA onVerified={() => setIsVerified(true)} />
        ) : (
          <Routes>
            <Route path="/" element={<VoteForm />} />
            <Route path="/results" element={<Results />} />
          </Routes>
        )}
      </div>
    </Router>
  );
}

export default App;